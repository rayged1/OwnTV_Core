package tv.own.owntv.core.stalker

import android.os.SystemClock
import android.util.JsonReader
import android.util.JsonToken
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.FilterInputStream
import java.io.IOException
import java.io.File
import java.io.InputStream
import java.net.URLEncoder
import java.util.TimeZone

/**
 * Stalker/Ministra (MAG portal) protocol client: portal-URL normalization, the MAC handshake
 * (`handshake` → Bearer token → `get_profile`), the MAG request headers, the content lists and
 * `create_link`, all in one place. Responses are small JSON wrapped as `{"js": <payload>}` and parsed with [JsonReader].
 */
open class StalkerClient(okHttpClient: OkHttpClient) {

    /**
     * Same pool and dispatcher as the shared client, but with connection-failure recovery ON.
     *
     * The shared client sets `retryOnConnectionFailure(false)` so SyncManager owns stream retries. A
     * portal call is not a stream: it is one small request, often the first in minutes, and portals
     * drop idle keep-alive sockets. OkHttp then hands the dead one out and the request dies instantly
     * with `unexpected end of stream` — which is exactly how a catch-up pick failed with no network
     * round trip at all, three milliseconds after it was made.
     */
    private val client: OkHttpClient = okHttpClient.newBuilder().retryOnConnectionFailure(true).build()

    /** The MAC is not authorized / the token expired / the portal answered `{"js":false}`. */
    class StalkerAuthException(message: String) : IOException(message)

    /**
     * Non-2xx portal response, carrying the status so callers can retry transient 429/5xx, and the
     * portal's own `Retry-After` (seconds → ms) when it sent one.
     */
    class StalkerHttpException(val code: Int, message: String, val retryAfterMs: Long? = null) : IOException(message)

    /**
     * The portal answered a request with the bare text `Authorization failed.` instead of JSON. On a
     * session that had been working, this is how Ministra tells a MAC it is asking too fast — so it is
     * a throttle (back off, then try again on a fresh handshake), not a login refused for good.
     */
    class StalkerRefusedException(message: String) : IOException(message)

    /** A successful probe: which API endpoint answered, and the token it handed out. */
    data class Handshake(val apiBase: String, val token: String)

    /** A live TV genre (Stalker's channel category). */
    data class Genre(val id: String, val title: String)

    /**
     * A live channel from `get_ordered_list`. [cmd] is the portal command (NOT playable) — resolve it
     * to a real URL at play time via [createLink]. [id] is the stable portal id → used as remoteId.
     */
    data class Channel(
        val id: String,
        val name: String,
        val number: String?,
        val cmd: String,
        val logo: String?,
        val xmltvId: String?,
        val genreId: String?,
        val archive: Boolean,
        val archiveDuration: Int,
    )

    /**
     * A VOD (movie) or series-show item from `get_ordered_list`. For a movie, [cmd] is the
     * portal command resolved to a real URL at play time via [createLink] (`type=vod`). For a series
     * SHOW, [cmd] carries the show command; per-episode URLs are minted with a `series=<ep>` param at
     * play time (episodes themselves are listed lazily when the show is opened). [id] is the stable
     * portal id → used as remoteId.
     */
    data class VodItem(
        val id: String,
        val name: String,
        val cmd: String?,
        val poster: String?,
        val year: Int?,
        val plot: String?,
        val rating: Double?,
        // The item's own category id (`category_id`). Used by the bulk `category=*` fast path to map each
        // item to its category (the per-category path already knows the category from the request).
        val categoryId: String?,
        // Epoch ms for the "Date added" sort, from Ministra's `video.added` column. Null on trimmed
        // reseller panels that omit it — the sort then falls through to playlist order.
        val addedAt: Long?,
        // `is_series` on a `type=vod` row: a show filed in the film catalogue. Portals with no series
        // section of their own list every show this way.
        val isSeries: Boolean = false,
    )

    /** One page of `get_ordered_list`: the items plus the totals needed to page through the rest. */
    data class Page<T>(val totalItems: Int, val maxPageItems: Int, val items: List<T>)

    /**
     * A season row from `get_ordered_list&movie_id=<show>` (D-2). [episodes] is the row's `series`
     * array — the episode numbers that exist. [cmd] is shared by the whole season; a playable URL is
     * minted per episode via [createLink] with `type=vod&series=<episode>`. [seasonNumber] is parsed
     * from the row id (`"280:2"` → 2) or the name ("Season 2"); callers fall back to the row index.
     */
    data class SeasonItem(
        val id: String,
        val name: String?,
        val cmd: String?,
        val seasonNumber: Int?,
        val episodes: List<Int>,
    )

    /**
     * A season of a show filed in the film catalogue, from Ministra's three-level VOD tree
     * (`type=vod&movie_id=<show>&season_id=0`). Unlike [SeasonItem] it carries no episode list and no
     * cmd: the episodes are one request further down ([getVodEpisodes]), and each episode's playable
     * file one more ([getVodEpisodeFileCmd]).
     */
    data class VodSeason(val id: String, val number: Int?, val name: String?)

    /** An episode row of a [VodSeason]: `series_number` is its number, `series_name` its own title. */
    data class VodEpisode(val id: String, val number: Int?, val title: String?)

    /** Where a [VodEpisode]'s file is listed: the parts of a [vodEpisodeRef]. */
    data class VodEpisodeRef(val movieId: String, val seasonId: String, val episodeId: String)

    /** One programme from `get_short_epg` — times in epoch ms. */
    data class ShortEpgEntry(val title: String, val description: String?, val startMs: Long, val stopMs: Long)

    /**
     * One row of the portal's per-day guide table, which is the only place the **archive token** for a
     * programme can be had. [id] is the portal's own `"<programme>_<channel>"` pair, and it is what
     * `tv_archive&action=create_link` expects inside its `cmd` — see [getArchiveDay]. [archived] is
     * the portal's `mark_archive`: its claim that this programme is inside the recorded window.
     */
    data class ArchiveEntry(val id: String, val startMs: Long, val stopMs: Long, val archived: Boolean)

    /**
     * Probe the API-endpoint candidates for [portalUrl] (`portal.php`, `stalker_portal/server/
     * load.php`, `server/load.php`) and return the first that completes a handshake. The winning
     * [Handshake.apiBase] should be reused for every later call on this source.
     *
     * A portal that redirects the handshake to another host is used at that host from then on.
     * OkHttp drops `Authorization` on a cross-host redirect, so every later call sent to the first
     * address would reach the real portal without its token and be refused.
     */
    open suspend fun resolveHandshake(portalUrl: String, mac: String, userAgent: String? = null): Handshake {
        var lastError: Exception? = null
        apiCandidates(portalUrl).forEach { apiBase ->
            try {
                var landed = apiBase
                val token = handshake(apiBase, mac, userAgent) { landed = it }
                Log.i(TAG, "handshake ok apiBase=$landed" + if (landed != apiBase) " redirectedFrom=$apiBase" else "")
                return Handshake(landed, token)
            } catch (c: CancellationException) {
                throw c
            } catch (e: Exception) {
                Log.w(TAG, "handshake candidate failed apiBase=$apiBase message=${e.message}")
                lastError = e
            }
        }
        throw lastError ?: IOException("No portal API endpoint candidates for $portalUrl")
    }

    /** `?type=stb&action=handshake` → the Bearer token used by every authorized call. */
    suspend fun handshake(apiBase: String, mac: String, userAgent: String? = null, onLanded: (String) -> Unit = {}): String {
        val url = "$apiBase?type=stb&action=handshake&token=&JsHttpRequest=1-xml"
        val js = request(url, mac, token = null, userAgent = userAgent, onLanded = onLanded) { readScalarFields(it) }
        return js["token"]?.takeIf { it.isNotBlank() }
            ?: throw IOException("Portal handshake returned no token")
    }

    /**
     * `?type=stb&action=get_profile` (with the Bearer token) — confirms the MAC is authorized and
     * returns the STB profile (scalar fields only; nested payloads are skipped). Optional second-step
     * device identity is sent only when supplied; MAC-only sources retain the original request shape.
     *
     * Some portals reject device identity sent without `stb_type`: confirmed against a real portal by
     * curl, `sn`/`device_id`/`device_id2` genuinely registered to this MAC were refused — "Device
     * conflict - device_id mismatch" — with `stb_type` omitted or naming the wrong model, and accepted
     * with the correct one. So the first request is exactly the one every working source already
     * makes, and only a conflict answer to a request carrying identity is retried once with
     * `stb_type` = [magModel] of the effective User-Agent. A source that works today sends one request,
     * unchanged; sending a guessed model up front could break a portal that checks it.
     *
     * That rejection comes back as an ordinary `200 OK` with a profile-shaped object (`status`, `msg`,
     * `block_msg` — no `id` and none of the real STB fields), so it reads as success to anything that
     * only checks "is this empty". Treated as fatal here instead of being cached as a working session:
     * silently accepting it meant the actual failure only surfaced later, as a bare-text `Authorization
     * failed.` on the next unrelated call.
     */
    open suspend fun getProfile(
        apiBase: String,
        mac: String,
        token: String,
        userAgent: String? = null,
        identity: StalkerDeviceIdentity = StalkerDeviceIdentity(),
    ): Map<String, String> = resolveProfile(identity, userAgent) { stbType ->
        request(profileUrl(apiBase, identity, stbType), mac, token, userAgent) { readScalarFields(it) }
    }

    /**
     * `?type=stb&action=do_auth` — the login some portals ask for on top of the MAC, sent between the
     * handshake and `get_profile`, and only when the playlist has a login. `{"js":true}` (or any
     * object) is a yes; `{"js":false}` is a refused login, reported as such rather than as a MAC
     * problem so the user is pointed at the right field.
     */
    open suspend fun doAuth(
        apiBase: String, mac: String, token: String, userAgent: String?,
        login: String, password: String, identity: StalkerDeviceIdentity = StalkerDeviceIdentity(),
    ) {
        val url = doAuthUrl(apiBase, login, password, identity)
        val accepted = request(url, mac, token, userAgent, scalarJs = true) { reader ->
            if (reader.peek() == JsonToken.BOOLEAN) reader.nextBoolean() else { reader.skipValue(); true }
        }
        if (!accepted) throw StalkerAuthException("Portal login rejected — check the username and password")
    }

    /**
     * `?type=account_info&action=get_main_info` — subscription status/expiry.
     * Optional and portal-quirky (expiry is often surfaced oddly, e.g. in `phone`); callers must
     * treat a failure or an empty map as "no account info", never as an error.
     */
    open suspend fun getAccountInfo(apiBase: String, mac: String, token: String, userAgent: String? = null): Map<String, String> {
        val url = "$apiBase?type=account_info&action=get_main_info&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { readScalarFields(it) }
    }

    // --- Content lists ---

    /** `?type=itv&action=get_genres` → live TV genres (the js payload is an array). */
    suspend fun getGenres(apiBase: String, mac: String, token: String, userAgent: String? = null): List<Genre> {
        val url = "$apiBase?type=itv&action=get_genres&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { readGenreArray(it) }
    }

    /** `?type=vod&action=get_categories` → movie categories (same `[{id,title}]` shape as genres). */
    suspend fun getVodCategories(apiBase: String, mac: String, token: String, userAgent: String? = null): List<Genre> {
        val url = "$apiBase?type=vod&action=get_categories&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { readGenreArray(it) }
    }

    /** `?type=series&action=get_categories` → series categories (same shape as genres). */
    suspend fun getSeriesCategories(apiBase: String, mac: String, token: String, userAgent: String? = null): List<Genre> {
        val url = "$apiBase?type=series&action=get_categories&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { readGenreArray(it) }
    }

    /**
     * `?type=itv&action=get_short_epg&ch_id=<id>&size=<n>` → the channel's now/next programmes
     * (the safe per-channel path; the OOM-prone bulk `get_epg_info` is never used).
     * The js payload is an array (some portals wrap it as `{data:[…]}`); entries with no readable
     * start/stop are dropped.
     */
    open suspend fun getShortEpg(
        apiBase: String, mac: String, token: String, userAgent: String?, channelId: String, size: Int = 8,
    ): List<ShortEpgEntry> {
        val url = "$apiBase?type=itv&action=get_short_epg&ch_id=${enc(channelId)}&size=$size&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { readShortEpg(it) }
    }

    /**
     * `?type=epg&action=get_simple_data_table&ch_id=<id>&date=<yyyy-MM-dd>&p=<page>` → one page of that
     * channel's guide for that day, each row carrying the archive token [ArchiveEntry.id].
     *
     * **This call is what makes catch-up work at all on a portal.** The archive `cmd` is
     * `auto /media/<programme>_<channel>.mpg`, and that first half is a portal-side programme id we
     * cannot compute: a Ministra facade parses the filename as `<programme_id>_<stream_id>` and looks
     * the pair up in its own guide. Sending a synthesized `<channel>_<start>_<duration>` instead — as
     * this client did until 1.0.43 — finds no row, so the portal answers **HTTP 200 with an empty
     * body**, which surfaces as an unhelpful `EOFException` and left catch-up silently dead.
     *
     * Note `type=epg`, not `itv` and not `tv_archive`: the facades that serve this route everything
     * else to an empty body, which is a fast way to be misled about what the portal supports.
     *
     * Times come back as true epoch seconds in `start_timestamp`/`stop_timestamp`, already matching
     * the wall clock the portal shows for the timezone this client sends in its cookie.
     */
    open suspend fun getArchiveDay(
        apiBase: String, mac: String, token: String, userAgent: String?, channelId: String, date: String, page: Int,
    ): Page<ArchiveEntry> {
        val url = "$apiBase?type=epg&action=get_simple_data_table&ch_id=${enc(channelId)}" +
            "&date=${enc(date)}&p=$page&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { readArchiveDay(it) }
    }

    private fun readArchiveDay(reader: JsonReader): Page<ArchiveEntry> {
        var total = 0
        var maxPer = 0
        val rows = ArrayList<Map<String, String>>()
        if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); return Page(0, 0, emptyList()) }
        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "total_items" -> total = nextIntLenient(reader) ?: 0
                "max_page_items" -> maxPer = nextIntLenient(reader) ?: 0
                "data" -> if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                    reader.beginArray()
                    while (reader.hasNext()) {
                        if (reader.peek() == JsonToken.BEGIN_OBJECT) rows.add(readScalarFields(reader)) else reader.skipValue()
                    }
                    reader.endArray()
                } else {
                    reader.skipValue()
                }
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        val items = rows.mapNotNull { f ->
            val id = f["id"]?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val start = epgTimeMs(f["start_timestamp"], f["time"]) ?: return@mapNotNull null
            val stop = epgTimeMs(f["stop_timestamp"], f["time_to"]) ?: return@mapNotNull null
            ArchiveEntry(id, start, stop, (f["mark_archive"]?.trim()?.toIntOrNull() ?: 0) > 0)
        }
        return Page(total, maxPer, items)
    }

    private fun readShortEpg(reader: JsonReader): List<ShortEpgEntry> {
        val rows = ArrayList<Map<String, String>>()
        when (reader.peek()) {
            JsonToken.BEGIN_ARRAY -> {
                reader.beginArray()
                while (reader.hasNext()) {
                    if (reader.peek() == JsonToken.BEGIN_OBJECT) rows.add(readScalarFields(reader)) else reader.skipValue()
                }
                reader.endArray()
            }
            JsonToken.BEGIN_OBJECT -> {
                reader.beginObject()
                while (reader.hasNext()) {
                    if (reader.nextName() == "data" && reader.peek() == JsonToken.BEGIN_ARRAY) {
                        reader.beginArray()
                        while (reader.hasNext()) {
                            if (reader.peek() == JsonToken.BEGIN_OBJECT) rows.add(readScalarFields(reader)) else reader.skipValue()
                        }
                        reader.endArray()
                    } else {
                        reader.skipValue()
                    }
                }
                reader.endObject()
            }
            else -> reader.skipValue()
        }
        return rows.mapNotNull { f ->
            val start = epgTimeMs(f["start_timestamp"], f["time"]) ?: return@mapNotNull null
            val stop = epgTimeMs(f["stop_timestamp"], f["time_to"]) ?: return@mapNotNull null
            val title = f["name"]?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            ShortEpgEntry(title, f["descr"]?.takeIf { it.isNotBlank() }, start, stop)
        }
    }

    /**
     * Download the whole portal guide (`?type=itv&action=get_epg_info&period=<days>`) to [dest]
     * **without parsing a byte of it**, returning the size.
     *
     * This is the call STBEmu and TiviMate make, and the reason their users see a full guide and a
     * working catch-up list on portals that offer only now/next otherwise.
     *
     * Written this way because of what a real portal did. The guide itself is quick — a measured
     * 9 MB in about a second for a 12 000-channel panel — but the first attempt parsed it as it
     * arrived and wrote each batch to the database with the response still open. Holding a
     * `Connection: keep-alive` socket idle while SQLite works invites the far end to hang up, and
     * that is exactly what happened: `unexpected end of stream`, no guide, every time.
     *
     * Taking the bytes at full speed and closing the connection *before* any parsing begins removes
     * the interaction altogether. A few megabytes on disk costs nothing, and the file is deleted as
     * soon as it has been read — unlike the XMLTV cache, nothing here is kept.
     *
     * [MAX_GUIDE_BYTES] stops a portal that answers with something absurd from filling the device.
     */
    open suspend fun downloadEpgInfo(
        apiBase: String, mac: String, token: String, userAgent: String?, periodDays: Int, dest: File,
    ): Long {
        val url = "$apiBase?type=itv&action=get_epg_info&period=$periodDays&JsHttpRequest=1-xml"
        return requestToFile(url, mac, token, userAgent, dest)
    }

    /**
     * Parse a guide previously fetched by [downloadEpgInfo]. No network, no time limit. [onEntry] is
     * called as each programme is read, so the caller writes in batches and nothing bigger than one
     * programme is held — a week of a thousand channels is hundreds of thousands of programmes.
     *
     * Both payload shapes are accepted, because portals disagree: an object keyed by channel id
     * (`{"data":{"1234":[…]}}` or `{"1234":[…]}`), or one flat array whose entries carry `ch_id`.
     * Entries with no readable start/stop or no title are skipped rather than failing the crawl.
     */
    open suspend fun parseEpgInfoFile(file: File, onEntry: suspend (channelId: String, entry: ShortEpgEntry) -> Unit) {
        file.inputStream().buffered().use { input -> parseEnvelope(input, scalarJs = false) { reader -> readEpgInfo(reader, onEntry) } }
    }

    private suspend fun readEpgInfo(reader: JsonReader, onEntry: suspend (String, ShortEpgEntry) -> Unit) {
        when (reader.peek()) {
            // One flat array — each entry names its own channel.
            JsonToken.BEGIN_ARRAY -> readEpgArray(reader, keyedChannelId = null, onEntry)
            JsonToken.BEGIN_OBJECT -> {
                reader.beginObject()
                while (reader.hasNext()) {
                    val name = reader.nextName()
                    when {
                        // `{"data": …}` — one level of wrapping, then the same two shapes again.
                        name == "data" -> readEpgInfo(reader, onEntry)
                        // Any other key that holds an array is a channel id → its programmes.
                        reader.peek() == JsonToken.BEGIN_ARRAY -> readEpgArray(reader, keyedChannelId = name, onEntry)
                        else -> reader.skipValue()
                    }
                }
                reader.endObject()
            }
            else -> reader.skipValue()
        }
    }

    private suspend fun readEpgArray(
        reader: JsonReader, keyedChannelId: String?, onEntry: suspend (String, ShortEpgEntry) -> Unit,
    ) {
        reader.beginArray()
        while (reader.hasNext()) {
            if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); continue }
            val f = readScalarFields(reader)
            val channelId = keyedChannelId ?: f["ch_id"]?.takeIf { it.isNotBlank() } ?: continue
            val start = epgTimeMs(f["start_timestamp"], f["time"]) ?: continue
            val stop = epgTimeMs(f["stop_timestamp"], f["time_to"]) ?: continue
            val title = f["name"]?.takeIf { it.isNotBlank() } ?: continue
            onEntry(channelId, ShortEpgEntry(title, f["descr"]?.takeIf { it.isNotBlank() }, start, stop))
        }
        reader.endArray()
    }

    /** Epoch-second field first; else the portal's `yyyy-MM-dd HH:mm:ss` wall-clock form (best effort —
     *  parsed in the device zone, which matches on the overwhelmingly common same-region portals). */
    private fun epgTimeMs(epochSec: String?, wallClock: String?): Long? {
        epochSec?.toLongOrNull()?.takeIf { it > 0 }?.let { return it * 1000 }
        val text = wallClock?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        return runCatching {
            java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).parse(text)?.time
        }.getOrNull()
    }

    /** `?type=vod&action=get_ordered_list&category=<id>&p=<page>` → one page of movies + paging totals. */
    suspend fun getVodPage(
        apiBase: String, mac: String, token: String, userAgent: String?, categoryId: String, page: Int,
    ): Page<VodItem> {
        val url = "$apiBase?type=vod&action=get_ordered_list&category=${enc(categoryId)}&sortby=added&p=$page&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { readVodPage(it, apiBase) }
    }

    /** `?type=series&action=get_ordered_list&category=<id>&p=<page>` → one page of series shows + totals. */
    suspend fun getSeriesPage(
        apiBase: String, mac: String, token: String, userAgent: String?, categoryId: String, page: Int,
    ): Page<VodItem> {
        val url = "$apiBase?type=series&action=get_ordered_list&category=${enc(categoryId)}&sortby=added&p=$page&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { readVodPage(it, apiBase) }
    }

    /**
     * `?type=series&action=get_ordered_list&movie_id=<show remoteId>&p=<page>` → one page of the
     * show's SEASONS, each carrying its `series` episode-number array. Category is included
     * because some portals require it alongside movie_id. [type] is `vod` for a show the portal
     * files in its film catalogue (see [VodItem.isSeries]).
     */
    suspend fun getSeriesSeasons(
        apiBase: String, mac: String, token: String, userAgent: String?, categoryId: String?, movieId: String, page: Int,
        type: String = "series",
    ): Page<SeasonItem> {
        val cat = categoryId?.takeIf { it.isNotBlank() }?.let { "&category=${enc(it)}" } ?: ""
        val url = "$apiBase?type=${enc(type)}&action=get_ordered_list$cat&movie_id=${enc(movieId)}&p=$page&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { readSeasonPage(it) }
    }

    /** `?type=vod&action=get_ordered_list&movie_id=<show>&season_id=0&p=<page>` → the seasons of a [VodSeason] show. */
    open suspend fun getVodSeasons(
        apiBase: String, mac: String, token: String, userAgent: String?, movieId: String, page: Int,
    ): Page<VodSeason> {
        val url = "$apiBase?type=vod&action=get_ordered_list&movie_id=${enc(movieId)}&season_id=0&episode_id=0&p=$page&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { reader ->
            readScalarPage(reader) { f ->
                val id = f["id"]?.takeIf { it.isNotBlank() } ?: return@readScalarPage null
                VodSeason(id, f["season_number"]?.trim()?.toIntOrNull(), (f["season_name"] ?: f["name"])?.takeIf { it.isNotBlank() })
            }
        }
    }

    /** `…&movie_id=<show>&season_id=<season>&p=<page>` → one page of that season's episodes. */
    open suspend fun getVodEpisodes(
        apiBase: String, mac: String, token: String, userAgent: String?, movieId: String, seasonId: String, page: Int,
    ): Page<VodEpisode> {
        val url = "$apiBase?type=vod&action=get_ordered_list&movie_id=${enc(movieId)}&season_id=${enc(seasonId)}&episode_id=0&p=$page&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { reader ->
            readScalarPage(reader) { f ->
                val id = f["id"]?.takeIf { it.isNotBlank() } ?: return@readScalarPage null
                VodEpisode(id, f["series_number"]?.trim()?.toIntOrNull(), f["series_name"]?.takeIf { it.isNotBlank() })
            }
        }
    }

    /**
     * `…&movie_id=<show>&season_id=<season>&episode_id=<episode>` → the episode's files. Returns the
     * first file's cmd (`/media/file_<id>.mpg`), which [createLink] turns into a URL like a film's.
     */
    open suspend fun getVodEpisodeFileCmd(
        apiBase: String, mac: String, token: String, userAgent: String?, movieId: String, seasonId: String, episodeId: String,
    ): String? {
        val url = "$apiBase?type=vod&action=get_ordered_list&movie_id=${enc(movieId)}&season_id=${enc(seasonId)}&episode_id=${enc(episodeId)}&p=1&JsHttpRequest=1-xml"
        val files = request(url, mac, token, userAgent) { reader -> readScalarPage(reader) { f -> f["cmd"]?.takeIf { it.isNotBlank() } } }
        return files.items.firstOrNull()
    }

    /** A `get_ordered_list` page whose rows only need their scalar fields; [row] drops a row by returning null. */
    private fun <T> readScalarPage(reader: JsonReader, row: (Map<String, String>) -> T?): Page<T> {
        var total = 0
        var maxPer = 0
        val items = ArrayList<T>()
        if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); return Page(0, 0, items) }
        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "total_items" -> total = nextIntLenient(reader) ?: 0
                "max_page_items" -> maxPer = nextIntLenient(reader) ?: 0
                "data" -> if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                    reader.beginArray()
                    while (reader.hasNext()) {
                        if (reader.peek() == JsonToken.BEGIN_OBJECT) row(readScalarFields(reader))?.let { items.add(it) } else reader.skipValue()
                    }
                    reader.endArray()
                } else {
                    reader.skipValue()
                }
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        return Page(total, maxPer, items)
    }

    private fun readSeasonPage(reader: JsonReader): Page<SeasonItem> {
        var total = 0
        var maxPer = 0
        val items = ArrayList<SeasonItem>()
        if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); return Page(0, 0, items) }
        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "total_items" -> total = nextIntLenient(reader) ?: 0
                "max_page_items" -> maxPer = nextIntLenient(reader) ?: 0
                "data" -> if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                    reader.beginArray()
                    while (reader.hasNext()) readSeasonItem(reader)?.let { items.add(it) }
                    reader.endArray()
                } else {
                    reader.skipValue()
                }
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        return Page(total, maxPer, items)
    }

    /** Like [readScalarFields] but also captures the row's `series` episode-number array. */
    private fun readSeasonItem(reader: JsonReader): SeasonItem? {
        if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); return null }
        val fields = LinkedHashMap<String, String>()
        val episodes = ArrayList<Int>()
        reader.beginObject()
        while (reader.hasNext()) {
            val name = reader.nextName()
            when {
                name == "series" && reader.peek() == JsonToken.BEGIN_ARRAY -> {
                    reader.beginArray()
                    while (reader.hasNext()) nextIntLenient(reader)?.let { episodes.add(it) }
                    reader.endArray()
                }
                else -> when (reader.peek()) {
                    JsonToken.STRING, JsonToken.NUMBER -> fields[name] = reader.nextString()
                    JsonToken.BOOLEAN -> fields[name] = reader.nextBoolean().toString()
                    JsonToken.NULL -> reader.nextNull()
                    else -> reader.skipValue()
                }
            }
        }
        reader.endObject()
        val id = fields["id"]?.takeIf { it.isNotBlank() } ?: return null
        return SeasonItem(
            id = id,
            name = fields["name"]?.takeIf { it.isNotBlank() },
            cmd = fields["cmd"]?.takeIf { it.isNotBlank() },
            seasonNumber = seasonNumberOf(id, fields["name"]),
            episodes = episodes.distinct().sorted(),
        )
    }

    private fun readGenreArray(reader: JsonReader): List<Genre> {
        val out = ArrayList<Genre>()
        if (reader.peek() == JsonToken.BEGIN_ARRAY) {
            reader.beginArray()
            while (reader.hasNext()) {
                val fields = readScalarFields(reader)
                val id = fields["id"] ?: continue
                // "*" is the portal's synthetic "All" category — get_ordered_list with it returns everything.
                out.add(Genre(id, fields["title"] ?: fields["name"] ?: id))
            }
            reader.endArray()
        } else {
            reader.skipValue()
        }
        return out
    }

    private fun readVodPage(reader: JsonReader, apiBase: String): Page<VodItem> {
        var total = 0
        var maxPer = 0
        val items = ArrayList<VodItem>()
        if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); return Page(0, 0, items) }
        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "total_items" -> total = nextIntLenient(reader) ?: 0
                "max_page_items" -> maxPer = nextIntLenient(reader) ?: 0
                "data" -> if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                    reader.beginArray()
                    while (reader.hasNext()) readVodItem(reader, apiBase)?.let { items.add(it) }
                    reader.endArray()
                } else {
                    reader.skipValue()
                }
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        return Page(total, maxPer, items)
    }

    private fun readVodItem(reader: JsonReader, apiBase: String): VodItem? {
        if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); return null }
        // Nested fields (the series episode list, actors arrays) are skipped by readScalarFields — the
        // show/movie row only needs the scalar metadata; episodes are fetched lazily on open.
        val f = readScalarFields(reader)
        val id = f["id"]?.takeIf { it.isNotBlank() } ?: return null
        return VodItem(
            id = id,
            name = f["name"] ?: f["o_name"] ?: id,
            cmd = f["cmd"]?.takeIf { it.isNotBlank() },
            poster = absoluteArt(f["screenshot_uri"] ?: f["poster"] ?: f["cover"], apiBase),
            year = parseYear(f["year"]),
            plot = f["description"]?.takeIf { it.isNotBlank() },
            rating = (f["rating_imdb"] ?: f["rating"])?.trim()?.toDoubleOrNull()?.takeIf { it > 0 },
            categoryId = (f["category_id"] ?: f["category"])?.takeIf { it.isNotBlank() && it != "*" },
            addedAt = parseAddedAt(f["added"]),
            isSeries = isFlagSet(f["is_series"]),
        )
    }

    private fun parseYear(raw: String?): Int? {
        val m = raw?.let { Regex("\\d{4}").find(it) } ?: return null
        return m.value.toIntOrNull()?.takeIf { it in 1900..2100 }
    }

    /**
     * Ministra's `video.added` → epoch ms. It is a portal-local datetime STRING
     * (`YYYY-MM-DD HH:MM:SS`, sometimes date-only), not an epoch — but a few panels do return a
     * numeric epoch, so both are accepted. Interpreted in the device timezone: the portal's own
     * offset is not exposed, and the value is only ever used to order items relative to each other.
     * Anything unparseable is null ("unknown"), which sorts last.
     */
    private fun parseAddedAt(raw: String?): Long? {
        val v = raw?.trim()?.takeIf { it.isNotBlank() && it != "0" } ?: return null
        // Numeric epoch (seconds or already-ms) — same guard the Xtream path uses.
        v.toLongOrNull()?.let { n ->
            return n.takeIf { it > 0 }?.let { if (it < 10_000_000_000L) it * 1000L else it }
        }
        val m = Regex("(\\d{4})-(\\d{2})-(\\d{2})(?:[ T](\\d{2}):(\\d{2})(?::(\\d{2}))?)?").find(v) ?: return null
        val (y, mo, d, h, mi, sec) = m.destructured
        return runCatching {
            java.util.GregorianCalendar(
                y.toInt(), mo.toInt() - 1, d.toInt(),
                h.toIntOrNull() ?: 0, mi.toIntOrNull() ?: 0, sec.toIntOrNull() ?: 0,
            ).apply { set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis.takeIf { it > 0 }
        }.getOrNull()
    }

    /**
     * `?type=itv&action=get_ordered_list&genre=<id>&p=<page>` → one page of live channels plus the
     * paging totals. Pages are small (max_page_items, typically ~14) so a page is parsed into a list.
     */
    suspend fun getLiveChannelsPage(
        apiBase: String, mac: String, token: String, userAgent: String?, genreId: String, page: Int,
    ): Page<Channel> {
        val url = "$apiBase?type=itv&action=get_ordered_list&genre=${enc(genreId)}&p=$page&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { reader -> readChannelPage(reader) }
    }

    /**
     * `?type=itv&action=get_all_channels` → the ENTIRE live list in one response (no paging). Far
     * faster than walking `get_ordered_list` per genre when a portal has thousands of channels served
     * ~14 per page. Some portals cap/deny it, so the caller falls back to per-genre paging on failure
     * or an empty result. Each channel still carries `tv_genre_id`, so categories map the same way.
     */
    suspend fun getAllChannels(apiBase: String, mac: String, token: String, userAgent: String? = null): List<Channel> {
        val url = "$apiBase?type=itv&action=get_all_channels&JsHttpRequest=1-xml"
        return request(url, mac, token, userAgent) { reader -> readAllChannels(reader) }
    }

    private fun readAllChannels(reader: JsonReader): List<Channel> {
        val out = ArrayList<Channel>()
        when (reader.peek()) {
            // js can be the data array directly, or {"data":[...]} (sometimes with total_items).
            JsonToken.BEGIN_ARRAY -> {
                reader.beginArray()
                while (reader.hasNext()) readChannel(reader)?.let { out.add(it) }
                reader.endArray()
            }
            JsonToken.BEGIN_OBJECT -> {
                reader.beginObject()
                while (reader.hasNext()) {
                    if (reader.nextName() == "data" && reader.peek() == JsonToken.BEGIN_ARRAY) {
                        reader.beginArray()
                        while (reader.hasNext()) readChannel(reader)?.let { out.add(it) }
                        reader.endArray()
                    } else {
                        reader.skipValue()
                    }
                }
                reader.endObject()
            }
            else -> reader.skipValue()
        }
        return out
    }

    /**
     * `?type=itv&action=create_link&cmd=<cmd>` → the real, short-lived stream URL (the leading
     * `ffmpeg `/`auto ` prefix stripped). This is the one call that mints a playable URL;
     * resolve immediately before playback, never at sync.
     */
    open suspend fun createLink(
        apiBase: String, mac: String, token: String, userAgent: String?, cmd: String,
        // "itv" for live; "vod" for movies AND series episodes. [episode] is the series episode
        // number minted into the URL via `series=<ep>` — null for live/movies.
        type: String = "itv", episode: Int? = null,
    ): String {
        val seriesParam = episode?.let { "&series=$it" } ?: ""
        val url = "$apiBase?type=${enc(type)}&action=create_link&cmd=${enc(cmd)}$seriesParam&forced_storage=0&disable_ad=0&JsHttpRequest=1-xml"
        val js = request(url, mac, token, userAgent) { readScalarFields(it) }
        val raw = js["cmd"]?.takeIf { it.isNotBlank() }
            ?: throw StalkerAuthException("Portal create_link returned no cmd — token may have expired")
        val resolved = stripCmdPrefix(raw)
        Log.i(TAG, "create_link inCmd=${redactForLog(cmd)} rawOut=${redactForLog(raw)} resolved=${redactForLog(resolved)}")
        return resolved
    }

    /** Mask token-ish query params so the resolved URL can be logged for debugging without leaking creds. */
    private fun redactForLog(s: String): String =
        s.replace(Regex("(?i)(token|password|pass)=[^&]*"), "$1=***")

    private fun readChannelPage(reader: JsonReader): Page<Channel> {
        var total = 0
        var maxPer = 0
        val items = ArrayList<Channel>()
        if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); return Page(0, 0, items) }
        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "total_items" -> total = nextIntLenient(reader) ?: 0
                "max_page_items" -> maxPer = nextIntLenient(reader) ?: 0
                "data" -> if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                    reader.beginArray()
                    while (reader.hasNext()) readChannel(reader)?.let { items.add(it) }
                    reader.endArray()
                } else {
                    reader.skipValue()
                }
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        return Page(total, maxPer, items)
    }

    private fun readChannel(reader: JsonReader): Channel? {
        if (reader.peek() != JsonToken.BEGIN_OBJECT) { reader.skipValue(); return null }
        val f = readScalarFields(reader)
        val id = f["id"]?.takeIf { it.isNotBlank() } ?: return null
        val cmd = f["cmd"]?.takeIf { it.isNotBlank() } ?: return null
        return Channel(
            id = id,
            name = f["name"] ?: f["title"] ?: id,
            number = f["number"]?.takeIf { it.isNotBlank() },
            cmd = cmd,
            logo = f["logo"]?.takeIf { it.isNotBlank() },
            xmltvId = f["xmltv_id"]?.takeIf { it.isNotBlank() },
            genreId = f["tv_genre_id"]?.takeIf { it.isNotBlank() },
            archive = hasArchive(f),
            archiveDuration = archiveDays(f["tv_archive_duration"]),
        )
    }


    /**
     * GET a portal URL with the MAG headers, unwrap the `{"js": <payload>}` envelope, and hand the
     * reader — positioned at the `js` value — to [parseJs]. `{"js": false/null/""}` (the portal's
     * "not authorized / token dead" shape) throws [StalkerAuthException] ("re-handshake").
     */
    /**
     * GET [url] straight to [dest], returning the bytes written. Same headers and cancellation as
     * [request]; the difference is that nothing is parsed while the connection is open — see
     * [downloadEpgInfo] for why that matters.
     */
    private suspend fun requestToFile(
        url: String, mac: String, token: String?, userAgent: String?, dest: File,
    ): Long = withContext(Dispatchers.IO) {
        val call = client.newCall(portalRequest(url, mac, token, userAgent))
        val coroutineContext = currentCoroutineContext()
        val startedAt = SystemClock.elapsedRealtime()
        val safeUrl = url.substringBefore('?')
        val cancellationHook = coroutineContext[Job]?.invokeOnCompletion { cause ->
            if (cause is CancellationException) call.cancel()
        }
        try {
            call.execute().use { response ->
                if (!response.isSuccessful) throw httpFailure(response.code, safeUrl)
                dest.parentFile?.mkdirs()
                var written = 0L
                response.body.byteStream().use { input ->
                    dest.outputStream().buffered().use { out ->
                        val buffer = ByteArray(DOWNLOAD_BUFFER)
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            written += read
                            if (written > MAX_GUIDE_BYTES) {
                                throw IOException("Portal guide exceeded $MAX_GUIDE_BYTES bytes")
                            }
                            out.write(buffer, 0, read)
                        }
                    }
                }
                Log.i(TAG, "guide download url=$safeUrl bytes=$written ms=${SystemClock.elapsedRealtime() - startedAt}")
                written
            }
        } finally {
            cancellationHook?.dispose()
        }
    }

    /** The MAG request every portal call is made with — headers in exactly one place. */
    private fun portalRequest(url: String, mac: String, token: String?, userAgent: String?): Request {
        val referer = "${portalRoot(url.substringBefore('?'))}/c/"
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent?.takeIf { it.isNotBlank() } ?: DEFAULT_MAG_USER_AGENT)
            .header("Cookie", "mac=${URLEncoder.encode(mac, "UTF-8")}; stb_lang=en; timezone=${TimeZone.getDefault().id}")
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("Referer", referer)
        if (token != null) builder.header("Authorization", "Bearer $token")
        return builder.build()
    }

    private suspend fun <T> request(
        url: String, mac: String, token: String?, userAgent: String?,
        /** Told the URL the answer came from once redirects are followed, without its query. */
        onLanded: (String) -> Unit = {},
        /** Hand a `true`/`false` payload to [parseJs] instead of reading `false` as a dead token. */
        scalarJs: Boolean = false,
        parseJs: suspend (JsonReader) -> T,
    ): T = withContext(Dispatchers.IO) {
        val httpRequest = portalRequest(url, mac, token, userAgent)

        val coroutineContext = currentCoroutineContext()
        val startedAt = SystemClock.elapsedRealtime()
        val safeUrl = url.substringBefore('?')
        val action = url.substringAfter("action=", "").substringBefore('&')
        val call = client.newCall(httpRequest)
        val cancellationHook = coroutineContext[Job]?.invokeOnCompletion { cause ->
            if (cause is CancellationException) call.cancel()
        }
        Log.d(TAG, "GET start url=$safeUrl action=$action")
        try {
            call.execute().use { response ->
                if (!response.isSuccessful) throw httpFailure(response.code, safeUrl, response.header("Retry-After"))
                onLanded(response.request.url.newBuilder().query(null).build().toString())
                val body = response.body
                body.byteStream().use { input ->
                    parseEnvelope(input, scalarJs, parseJs).also {
                        Log.d(TAG, "GET done url=$safeUrl action=$action totalMs=${SystemClock.elapsedRealtime() - startedAt}")
                    }
                }
            }
        } finally {
            cancellationHook?.dispose()
        }
    }

    /**
     * Find the `js` field of the top-level object and run [parseJs] on its value.
     *
     * [parseJs] is a *suspending* function so that a reader can do real work per item — the guide
     * crawl writes each batch to the database as it parses, and therefore never holds the whole
     * payload. Callers that just build a value pass an ordinary lambda and are unaffected.
     *
     * [input] is wrapped in [HeadPeekingInputStream] so a "not JSON" failure can log what the
     * portal actually sent — a handful of bytes, never the whole body (which for the guide crawl can
     * be up to [MAX_GUIDE_BYTES]). This is diagnostic only: [reader]'s lenient mode is what decides
     * whether the response parses, not this peek. The quote goes to the log, not into the exception:
     * an exception's message reaches the sync error and warning text the user reads.
     */
    private suspend fun <T> parseEnvelope(input: InputStream, scalarJs: Boolean, parseJs: suspend (JsonReader) -> T): T {
        val peeking = HeadPeekingInputStream(input, RESPONSE_PEEK_BYTES)
        JsonReader(peeking.reader(Charsets.UTF_8)).use { reader ->
            reader.isLenient = true // some portals prefix/pad the JSON
            if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                val got = reader.peek()
                Log.w(TAG, "portal response is not JSON (got $got): ${redactForLog(peeking.head())}")
                if (isRefusal(peeking.head())) throw StalkerRefusedException("Portal refused the request (Authorization failed)")
                throw IOException("Portal response is not JSON (got $got)")
            }
            reader.beginObject()
            var result: T? = null
            var found = false
            while (reader.hasNext()) {
                if (reader.nextName() == "js") {
                    when (reader.peek()) {
                        JsonToken.BEGIN_OBJECT, JsonToken.BEGIN_ARRAY -> { result = parseJs(reader); found = true }
                        JsonToken.BOOLEAN -> if (scalarJs) {
                            result = parseJs(reader); found = true
                        } else {
                            reader.skipValue(); throw StalkerAuthException("Portal returned an empty payload — token expired or MAC not authorized")
                        }
                        // {"js":false} / {"js":null} / {"js":""} — token expired / MAC not authorized.
                        else -> { reader.skipValue(); throw StalkerAuthException("Portal returned an empty payload — token expired or MAC not authorized") }
                    }
                } else {
                    reader.skipValue()
                }
            }
            reader.endObject()
            if (!found) throw IOException("Portal response has no \"js\" payload")
            @Suppress("UNCHECKED_CAST")
            return result as T
        }
    }

    private fun nextIntLenient(reader: JsonReader): Int? = when (reader.peek()) {
        JsonToken.NUMBER -> reader.nextInt()
        JsonToken.STRING -> reader.nextString().toIntOrNull()
        JsonToken.NULL -> { reader.nextNull(); null }
        else -> { reader.skipValue(); null }
    }

    private fun readScalarFields(reader: JsonReader): Map<String, String> {
        val fields = LinkedHashMap<String, String>()
        reader.beginObject()
        while (reader.hasNext()) {
            val name = reader.nextName()
            when (reader.peek()) {
                JsonToken.STRING -> fields[name] = reader.nextString()
                JsonToken.NUMBER -> fields[name] = reader.nextString()
                JsonToken.BOOLEAN -> fields[name] = reader.nextBoolean().toString()
                JsonToken.NULL -> reader.nextNull()
                else -> reader.skipValue()
            }
        }
        reader.endObject()
        return fields
    }

    /** URL-encode a query value (the `cmd` carries `/`, `:`, spaces the portal must receive intact). */
    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    companion object {
        private const val TAG = "StalkerClient"

        /** A season row's number: the id suffix ("280:2"), 0 for Specials, else a trailing number in its name. */
        internal fun seasonNumberOf(id: String, name: String?): Int? {
            // "280:2" — the suffix after ':' is the season on classic portals.
            id.substringAfterLast(':', "").toIntOrNull()?.let { return it }
            // A "Specials" season is season 0. Without this it had no number, took its list position,
            // and — listed first — merged into Season 1.
            if (name != null && SPECIALS.containsMatchIn(name)) return 0
            // Else a trailing number in the name ("Season 2", "S02").
            return name?.let { Regex("(\\d+)\\s*$").find(it.trim())?.value?.toIntOrNull() }
        }

        /** "Specials", "Special", "Season 0 - Specials": the provider's season 0. */
        private val SPECIALS = Regex("""\bspecials?\b""", RegexOption.IGNORE_CASE)

        /**
         * A poster or cover as a loadable URL. Many portals send a server path
         * (`/stalker_portal/screenshots/…`), which is resolved against the API base's origin — not
         * its path, which would double `/stalker_portal`. Absolute URLs are kept; blank and `"0"`
         * mean none.
         */
        internal fun absoluteArt(raw: String?, apiBase: String): String? {
            val value = raw?.trim()?.takeIf { it.isNotEmpty() && it != "0" } ?: return null
            if (value.toHttpUrlOrNull() != null) return value
            val origin = apiBase.toHttpUrlOrNull()?.newBuilder()?.encodedPath("/")?.query(null)?.build() ?: return value
            return origin.resolve(value)?.toString() ?: value
        }


        /** Ministra states an archive length in hours; the app stores and shows days. */
        private const val HOURS_PER_DAY = 24

        /** Copy buffer for the guide download — big enough that a 9 MB reply is a few hundred reads. */
        private const val DOWNLOAD_BUFFER = 64 * 1024

        /** A portal guide larger than this is not a guide; refuse it rather than fill the device. */
        private const val MAX_GUIDE_BYTES = 192L * 1024 * 1024

        /** How much of a non-JSON response is worth quoting in the error — enough to name the shape, not the whole body. */
        private const val RESPONSE_PEEK_BYTES = 200

        /** Classic MAG-box UA most portals accept; overridable per source (MAG254/270/420 presets). */
        const val DEFAULT_MAG_USER_AGENT =
            "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 2721 Safari/533.3"

        /** Fallback model when [userAgent] carries none of the recognized MAG tokens — matches the default UA above. */
        private const val DEFAULT_MAG_MODEL = "MAG200"

        /** The MAG model tokens actually issued in the wild, longest-prefix-safe order doesn't matter: exact word match. */
        private val KNOWN_MAG_MODELS = listOf(
            "MAG522", "MAG520", "MAG425", "MAG424", "MAG420", "MAG352", "MAG351", "MAG349",
            "MAG345", "MAG322", "MAG315", "MAG295", "MAG275", "MAG270", "MAG254", "MAG250", "MAG245", "MAG200",
        )

        /**
         * The `MAGnnn` token for a given [userAgent] — one of the MAG preset strings in
         * `MAG_USER_AGENTS` (`SetupText.kt`), each of which embeds its own model name. Used only for
         * `get_profile`'s `stb_type` on a device-conflict retry (see [getProfile]); `X-User-Agent`'s
         * `Model:` in [portalRequest] deliberately stays a fixed `MAG250`, as it always has. Falls
         * back to [DEFAULT_MAG_MODEL] for a custom `User-Agent` that names no known model — which is
         * the normal case for a hand-typed UA that mirrors a real STB client's generic string (those
         * always say "MAG200" regardless of actual hardware); such a source should pick the matching
         * preset instead of typing the UA, so the real model still reaches `stb_type`.
         */
        internal fun magModel(userAgent: String): String =
            KNOWN_MAG_MODELS.firstOrNull { userAgent.contains(it, ignoreCase = true) } ?: DEFAULT_MAG_MODEL

        /**
         * [stbType] is only meaningful alongside device identity — a portal that checks `device_id`
         * against it has nothing to check for a MAC-only source, and MAC-only sources must keep their
         * original request shape (see [getProfile]'s kdoc), so it is omitted whenever [identity] is
         * empty, same as the identity fields themselves.
         */
        /** [doAuth]'s request: the login, plus the device ids when the playlist has them. */
        internal fun doAuthUrl(apiBase: String, login: String, password: String, identity: StalkerDeviceIdentity): String = buildString {
            append(apiBase)
            append("?type=stb&action=do_auth")
            append("&login=${URLEncoder.encode(login, "UTF-8")}")
            append("&password=${URLEncoder.encode(password, "UTF-8")}")
            append("&device_id=${URLEncoder.encode(identity.deviceId.orEmpty(), "UTF-8")}")
            append("&device_id2=${URLEncoder.encode(identity.deviceId2.orEmpty(), "UTF-8")}")
            append("&JsHttpRequest=1-xml")
        }

        internal fun profileUrl(apiBase: String, identity: StalkerDeviceIdentity, stbType: String? = null): String = buildString {
            append(apiBase)
            append("?type=stb&action=get_profile&hd=1&auth_second_step=")
            append(if (identity.hasAny) '1' else '0')
            identity.serialNumber?.takeIf { it.isNotBlank() }?.let { append("&sn=${URLEncoder.encode(it, "UTF-8")}") }
            if (identity.hasAny) stbType?.takeIf { it.isNotBlank() }?.let { append("&stb_type=${URLEncoder.encode(it, "UTF-8")}") }
            identity.deviceId?.takeIf { it.isNotBlank() }?.let { append("&device_id=${URLEncoder.encode(it, "UTF-8")}") }
            identity.deviceId2?.takeIf { it.isNotBlank() }?.let { append("&device_id2=${URLEncoder.encode(it, "UTF-8")}") }
            identity.signature?.takeIf { it.isNotBlank() }?.let { append("&signature=${URLEncoder.encode(it, "UTF-8")}") }
            append("&JsHttpRequest=1-xml")
        }

        /**
         * `get_profile`'s rejection shape: a device-identity mismatch comes back as an ordinary
         * `200 OK` object carrying `msg`/`block_msg` but none of the real profile fields (no `id`).
         * Confirmed against a real portal with `sn`/`device_id`/`device_id2` that were genuinely
         * registered to the MAC but sent with no `stb_type`, or the wrong one — see [getProfile].
         * Returns the message worth showing, or `null` for an ordinary profile.
         */
        internal fun deviceConflictMessage(profile: Map<String, String>): String? {
            if (!profile["id"].isNullOrBlank()) return null
            return profile["msg"]?.takeIf { it.isNotBlank() } ?: profile["block_msg"]?.takeIf { it.isNotBlank() }
        }

        /**
         * [getProfile]'s decision, apart from the network: [fetch] with no `stb_type` first, and once
         * more with one only after a device conflict on a request that carried identity.
         */
        internal suspend fun resolveProfile(
            identity: StalkerDeviceIdentity,
            userAgent: String?,
            fetch: suspend (stbType: String?) -> Map<String, String>,
        ): Map<String, String> {
            var profile = fetch(null)
            if (identity.hasAny && profile.isNotEmpty() && deviceConflictMessage(profile) != null) {
                val model = magModel(userAgent?.takeIf { it.isNotBlank() } ?: DEFAULT_MAG_USER_AGENT)
                Log.i(TAG, "get_profile device conflict — retrying once with stb_type=$model")
                profile = fetch(model)
            }
            if (profile.isEmpty()) throw StalkerAuthException("Portal accepted the handshake but returned an empty profile — the MAC may not be authorized")
            deviceConflictMessage(profile)?.let { throw StalkerAuthException(it) }
            return profile
        }

        /**
         * Which exception a non-2xx portal response deserves — the one place that decides whether a
         * status means "your token is dead" or "you are asking too fast".
         *
         * **Only 401 is an auth failure.** 403 used to be lumped in with it, and that was wrong for
         * the portals people actually use: Ministra and its reseller panels answer 403 when a MAC has
         * too many connections open or is being crawled faster than the panel likes, which is a
         * *throttle*, not a logout. Treating it as auth made every 403 tear down a perfectly good
         * session and handshake again — the worst possible reply to "slow down", and the cause of the
         * 403 storms and endless loading reported after 4.2.4 removed the pause between page fetches.
         *
         * A token that genuinely died still reaches us either as 401 or, far more commonly, as the
         * portal's own `{"js":false}` body, which [parseEnvelope] already turns into a
         * [StalkerAuthException] — so nothing is lost by letting 403 back off and retry instead.
         */
        /**
         * Whether this channel has a catch-up archive.
         *
         * `tv_archive` is **Xtream's** field name and Ministra does not send it — a portal channel carries
         * `enable_tv_archive` and `archive` instead. Reading only the Xtream name meant every Stalker
         * channel was recorded as having no archive, which is why catch-up never appeared on a portal even
         * when the portal offered it: on the test portal, 427 of 11 545 channels have it.
         *
         * All three are accepted, because panels differ and any one of them saying yes is a yes.
         */
        internal fun hasArchive(f: Map<String, String>): Boolean =
            listOf("enable_tv_archive", "archive", "tv_archive")
                .any { (f[it]?.trim()?.toIntOrNull() ?: 0) > 0 }

        /**
         * How far back the archive goes, in **days**, from Ministra's `tv_archive_duration` — which is in
         * **hours**. The test portal reports 24, 48, 72 and 168: every value a multiple of 24, which is
         * one, two, three and seven days. Stored as days because that is what `ChannelEntity.catchupDays`
         * and the catch-up picker mean by it; keeping the raw hours there would have offered a 72-day
         * archive on a three-day one.
         *
         * A value below 24 is taken at face value as days: a panel reporting "7" plainly means a week, and
         * seven hours of archive is not a thing anyone sells.
         */
        internal fun archiveDays(raw: String?): Int {
            val value = raw?.trim()?.toIntOrNull() ?: return 0
            if (value <= 0) return 0
            return if (value < HOURS_PER_DAY) value else value / HOURS_PER_DAY
        }

        internal fun httpFailure(code: Int, safeUrl: String, retryAfter: String? = null): IOException =
            if (code == 401) StalkerAuthException("Portal rejected the request (HTTP $code)")
            else StalkerHttpException(code, "HTTP $code for $safeUrl", retryAfterMs(retryAfter))

        /** `Retry-After` in seconds → ms. The HTTP-date form is not used by portals and is ignored. */
        internal fun retryAfterMs(header: String?): Long? =
            header?.trim()?.toLongOrNull()?.takeIf { it >= 0 }?.let { it * 1_000L }

        /** A portal flag: `1`, `"1"` or `true`. */
        internal fun isFlagSet(raw: String?): Boolean = raw?.trim()?.let { it == "1" || it.equals("true", ignoreCase = true) } == true

        /** Ministra's bare-text refusal, `Authorization failed.`, as opposed to any other non-JSON body. */
        internal fun isRefusal(body: String): Boolean =
            body.trim().startsWith("Authorization failed", ignoreCase = true)

        /** Play-command prefixes minted by `create_link` — everything after them is the playable URL. */
        private val CMD_PREFIXES = listOf("ffmpeg ", "ffrt2 ", "ffrt3 ", "ffrt ", "auto ")

        /**
         * Canonicalize a MAC to `AA:BB:CC:DD:EE:FF`. Accepts `aabbccddeeff`, `aa-bb-…`, `aa.bb.…`
         * or colon form, any case. Returns null if it isn't 12 alphanumeric characters.
         *
         * Deliberately NOT restricted to hex: several Stalker panels hand out "virtual" MACs that
         * contain letters past F (e.g. …:PQ). The portal only ever echoes the string back to itself,
         * so rejecting them locked real users out for no protocol reason. Only the 12-symbol shape
         * is enforced, which still catches typos and truncated pastes.
         */
        fun canonicalizeMac(raw: String): String? {
            val body = raw.trim().replace(Regex("[:\\-. ]"), "")
            if (body.length != 12 || !body.all { it.isDigit() || it.lowercaseChar() in 'a'..'z' }) return null
            return body.uppercase().chunked(2).joinToString(":")
        }

        /** Strip the `/c/` UI path and trailing slashes off whatever the user pasted → the portal root. */
        fun portalRoot(input: String): String {
            var root = input.trim().trimEnd('/')
            if (root.endsWith("/c", ignoreCase = true)) root = root.dropLast(2).trimEnd('/')
            return root
        }

        /**
         * API-endpoint candidates for a portal URL, in probe order. A pasted direct `.php`
         * endpoint is honored first; otherwise try `portal.php`, then the stalker_portal layouts.
         */
        fun apiCandidates(input: String): List<String> {
            val trimmed = input.trim().trimEnd('/')
            if (trimmed.endsWith(".php", ignoreCase = true)) {
                return listOf(trimmed) + apiCandidates(trimmed.substringBeforeLast('/')).filterNot { it == trimmed }
            }
            val root = portalRoot(trimmed)
            return listOf(
                "$root/portal.php",
                "$root/stalker_portal/server/load.php",
                "$root/server/load.php",
            )
        }

        /** True when the URL is at least parseable — the add-source form's cheap pre-check. */
        fun isValidPortalUrl(input: String): Boolean {
            val root = portalRoot(input)
            return (root.startsWith("http://", true) || root.startsWith("https://", true)) && root.toHttpUrlOrNull() != null
        }

        /** Drop the `ffmpeg `/`ffrt*`/`auto ` prefix a `create_link` cmd carries; plain URLs pass through. */
        fun stripCmdPrefix(cmd: String): String {
            val trimmed = cmd.trim()
            CMD_PREFIXES.forEach { prefix ->
                if (trimmed.startsWith(prefix, ignoreCase = true)) return trimmed.removeRange(0, prefix.length).trim()
            }
            return trimmed
        }

        /**
         * [cmd] without its `play_token` query value. Portals that embed the playable URL in the
         * channel list mint a new token on every `get_all_channels`, so a cmd compared with it in
         * place differs on every re-sync and the whole live list is rewritten each time. It is left
         * out of the comparison only; the newest token is still stored (see [hasPlayToken]).
         */
        fun withoutPlayToken(cmd: String): String = cmd.replace(PLAY_TOKEN, "")

        /**
         * What an episode of a [VodSeason] show stores as its stream URL. Such an episode has no cmd of
         * its own until its file is listed, and that listing is a request per episode — so the
         * listing stores where the file is, and [StreamUrlResolver] fetches it at play time.
         */
        fun vodEpisodeRef(movieId: String, seasonId: String, episodeId: String): String =
            "$VOD_EPISODE_SCHEME$movieId/$seasonId/$episodeId"

        /** The parts of a [vodEpisodeRef], or null for any other stored URL. */
        fun parseVodEpisodeRef(stored: String): VodEpisodeRef? {
            if (!stored.startsWith(VOD_EPISODE_SCHEME)) return null
            val parts = stored.removePrefix(VOD_EPISODE_SCHEME).split('/')
            if (parts.size != 3 || parts.any { it.isBlank() }) return null
            return VodEpisodeRef(parts[0], parts[1], parts[2])
        }

        private const val VOD_EPISODE_SCHEME = "stalker-vod-episode://"

        /** True when [cmd] carries a `play_token`, so its stored copy is renewed on each re-sync. */
        fun hasPlayToken(cmd: String): Boolean = PLAY_TOKEN.containsMatchIn(cmd)

        private val PLAY_TOKEN = Regex("(?i)[?&]play_token=[^&\\s]*(?=&|\\s|$)")

        /**
         * True when a prefix-stripped channel `cmd` is ALREADY a complete, playable URL (some portals
         * embed the real stream URL — mac/stream/token — directly in the channel list, e.g.
         * `…/play/live.php?mac=…&stream=12345&…`). Those must be played AS-IS: routing them through
         * `create_link` on such portals blanks the stream id (→ HTTP 405). A `localhost`/`127.0.0.1`
         * host means it's a placeholder that genuinely needs `create_link`.
         */
        fun isDirectPlayUrl(strippedCmd: String): Boolean {
            val url = strippedCmd.toHttpUrlOrNull() ?: return false
            val host = url.host
            if (host.equals("localhost", ignoreCase = true) || host == "127.0.0.1") return false
            // A real host + a stream/query is a ready-to-play URL. Placeholder cmds (…/ch/12345_) have
            // no query and rely on create_link.
            return url.querySize > 0 || url.encodedPath.contains(".")
        }
    }
}

/**
 * Passes bytes through unchanged, but remembers the first [limit] of them so a caller that gave up
 * partway through the stream (e.g. [StalkerClient]'s "not JSON" check) can still say what the portal
 * actually sent. Never buffers past [limit] — the guide crawl can be tens of megabytes, and this exists
 * to describe a failure, not to re-implement the body.
 */
private class HeadPeekingInputStream(input: InputStream, private val limit: Int) : FilterInputStream(input) {
    private val captured = java.io.ByteArrayOutputStream(minOf(limit, 64))

    override fun read(): Int {
        val b = super.read()
        if (b != -1 && captured.size() < limit) captured.write(b)
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val n = super.read(b, off, len)
        if (n > 0 && captured.size() < limit) captured.write(b, off, minOf(n, limit - captured.size()))
        return n
    }

    /** The bytes seen so far, up to [limit], decoded as UTF-8 (replacing anything that isn't valid). */
    fun head(): String = captured.toByteArray().toString(Charsets.UTF_8)
}
